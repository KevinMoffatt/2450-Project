function [ t, x, v ] = RK4_race( h, x0, v0, p )
%RK4_race Implements 4th order Runge-Kutta based on parameters for the ME
%EN 2450 final project
%   Inputs: h - step size
%           x0 - initial x value
%           v0 - initial v value
%           p - vector containing the values of all relevant physical
%           parameters

m = p(1);       % mass of model train, kg
mw = p(2);      % wheel mass, kg
D = p(3);       % diameter of model train, m
Lt = p(4);      % length of model train, m
rho = p(5);     % air density, kg/m^3
Cd = p(6);      % drag coefficient
Cr = p(7);      % rolling friction coefficient
Lr = p(8);      % piston stroke length, m
g = p(9);       % gravity, m/s^2
rp = p(10);     % pinion gear radius, m
rw = p(11);     % wheel radius, m
P0 = p(12);     % initial tank pressure, Pa
Dp = p(13);     % piston diameter, m
A = p(14);      % frontal area of train, m^2

Ap = (pi/4)*Dp^2;       % cross sectional area of the piston, m^2
V0 = (pi/4)*(D^2)*Lt;   % initial tank volume, m^3
i = 1; % incrementing variable for while loop

% Establishing initial variables
t0 = 0;
t(i) = t0;
x(i) = x0;
v(i) = v0;

% Creating function handles for the shooting method
dx1 = @(t0,x0,v0) v0;
dv1 = @(t0,x0,v0) (m + mw/2)^(-1)*(rp*(Ap/rw)*(P0*V0/(V0+Ap*rp/rw*(x0)))-1/2*Cd*rho*A*(v0)^2-Cr*m*g);
dx2 = @(t0,x0,v0) v0;
dv2 = @(t0,x0,v0) -((Cd*rho*A*(v0^2))/(2*m))-Cr*g;

% Implementing while loop to check for when the train stops
while v0 >= 0
    % Using an if statement to carry out the shooting method based on
    % whether the train is accelerating or decelerating.
    if x0 <= (Lr*rw/rp)
        k11 = dx1(t0,x0,v0);
        k12 = dv1(t0,x0,v0);
        k21 = dx1(t0+.5*h,x0+.5*k11*h,v0+.5*k12*h);
        k22 = dv1(t0+.5*h,x0+.5*k11*h,v0+.5*k12*h);
        k31 = dx1(t0+.5*h,x0+.5*k21*h,v0+.5*k22*h);
        k32 = dv1(t0+.5*h,x0+.5*k21*h,v0+.5*k22*h);
        k41 = dx1(t0+h,x0+k31*h,v0+k32*h);
        k42 = dv1(t0+h,x0+k31*h,v0+k32*h);
    else
        k11 = dx2(t0,x0,v0);
        k12 = dv2(t0,x0,v0);
        k21 = dx2(t0+(h/2),x0+.5*k11*h,v0+.5*k12*h);
        k22 = dv2(t0+(h/2),x0+.5*k11*h,v0+.5*k12*h);
        k31 = dx2(t0+(h/2),x0+.5*k21*h,v0+.5*k22*h);
        k32 = dv2(t0+(h/2),x0+.5*k21*h,v0+.5*k22*h);
        k41 = dx2(t0+h,x0+k31*h,v0+k32*h);
        k42 = dv2(t0+h,x0+k31*h,v0+k32*h);
    end
    % Calculating distance and velocity using 4th Order Runge Kutta
        x0 = x0 + (h/6)*(k11+2*k21+2*k31+k41);
        v0 = v0 + (h/6)*(k12+2*k22+2*k32+k42);
        t0 = t(i) + h;
        i = i + 1;
        t(i) = t0;
        x(i) = x0;
        v(i) = v0;
end
end

