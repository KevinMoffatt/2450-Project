% Josh Call  Justin Lord  Kevin Moffatt
% ME 2450 Final Design Project
% 12/14/16
clc, clear, close all

tic; % Start timer

%Establishing parameter vectors and values
Lt = [.5:.1:1]; %Length of model train (in m)
Do = [.1:.05:.2]; %Outer diameter of model train (m)
pt = [1400, 2700, 7700]; %Density of train material (PVC, Aluminum - 6061, galvanized steel)
Pgage = [5:10:100] * 6894.76;     %Initial tank pressure (from psig to Pa)
Patm = 12.6 * 6894.76;  %Atmospheric pressure in Salt Lake City (psi to Pa)
P0 = Pgage + Patm;  %Initial total pressure in the tank (Pa)
Dw = .035;  %Wheel diameter (m)
rw = Dw/2;   %Wheel radius (inches to m)
rg = linspace(.01,rw,3);  %Pinion gear radius (m)
Lr = [.4:.05:.75];     %Piston stroke length (m)
Lp = 2 * Lr;        %Length of piston (m)
Dp = [1/2:1/8:3] * .0254;   %Piston diameter (in to m)
deadWeight = linspace(0,3.5,6);  %Adding weight to the train (kg)

%Setting up constant values
pa = 1.067;        %Air density (kg/m^3)
Cd = 0.8;             %Drag coefficient
Cr = .028992;           %Rolling friction coefficient
muS = .5;            %Coefficient of static friction
mw = .1;            %Wheel mass (kg)
g = 9.81;           %Acceleration due to gravity in m/s^2

%Test Parameter Matrix Set Up Function
ParameterMatrix = ParameterMatrixSetUp(Lt,Do,pt,P0,rg,Lr,Dp,deadWeight,pa,Patm,Cd,Cr,muS,Dw,mw);

%Test Train Optimization function
Optimal = TrainOptimization(ParameterMatrix);

runTime = toc; %Stop timer

%Indexing out the appropriate arrays
t = Optimal{1};
x = Optimal{2};
v = Optimal{3};
OptimalSet = Optimal{4};
    Lt = OptimalSet(1);
    Do = OptimalSet(2);
    pt = OptimalSet(3);
    P0 = OptimalSet(4);
    rg = OptimalSet(5);
    Lr = OptimalSet(6);
    Dp = OptimalSet(7);
    deadWeight = OptimalSet(8);
    pa = OptimalSet(9);
    Patm = OptimalSet(10);
    Cd = OptimalSet(11);
    Cr = OptimalSet(12);
    muS = OptimalSet(13);
    Dw = OptimalSet(14);
    mw = OptimalSet(15);
m = Optimal{5};
iterations = Optimal{6};
Mp = Optimal{7};

%% Output to figures and command window

Lp = 2 * Lr; %Reestablishing piston length based off optimal stroke length

%Indexing out the time at which our train crosses the finish line
xVal = 12;
tmp = abs(x-xVal);
[index index] = min(tmp);
tLine = t(index);

%Printing essential measurements to the command window
fprintf('Run time is %f seconds\n',runTime);
fprintf('Number of iterations required to run the search: %d\n',iterations);
fprintf('Final distance traveled by the train: %f m\n',x(end));
fprintf('Time it takes to reach the finish line: %f seconds\n',tLine);
fprintf('Optimal tank length: %f m\n',Lt);
fprintf('Optimal tank diameter: %f m\n',Do);
fprintf('Optimal train material density: %d kg/m^3\n',pt);
fprintf('Optimal train mass: %f kg\n',m);
fprintf('Optimal initial tank gage pressure: %f Pa\n',P0 - Patm);
fprintf('Optimal pinion gear radius: %f m\n',rg);
fprintf('Optimal piston stroke length: %f m\n',Lr);
fprintf('Optimal piston length: %f m\n',Lp);
fprintf('Optimal piston diameter: %f m\n',Dp);
fprintf('Optimal piston mass: %f kg\n',Mp);

%Plotting position versus time with lines at 12 and 14 meters
figure
a1 = plot(t,x);
title('Position v. Time');
xlabel('Time [sec]');
ylabel('Position [m]');
axis([0 12 0 15]);
hold on
a2 = plot([0 tLine],[12 12],'--g');
a3 = plot([tLine tLine],[0 12],'--g');
a4 = plot([0 12],[14 14],'--r');
legend([a1 a2 a4],'Postion v. Time','Time at 12 m','Time at 14 m','Location','southeast')
hold off

%Plotting velocity versus time
figure
plot(t,v);
title('Velocity v. Time');
xlabel('Time [sec]');
ylabel('Velocity [m/s]');